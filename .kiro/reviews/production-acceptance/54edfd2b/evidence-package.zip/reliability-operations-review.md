# Reliability, Operations & External Integrations Review

**Frozen commit:** `54edfd2b08f5fd61095b3a94c33bd5b981935c28`  
**Agent:** F (Ops)  
**Severity rubric:** `severity-rubric.md`  
**Automated gates:** Run 2 **PASS**  
**Conclusion:** **BLOCKED** (prod deploy + remaining externals + health)

## P0 Operations Findings

| ID | Status | Title |
|---|---|---|
| ACC-OPS-P0-001 | OPEN | No application health/readiness |
| ACC-OPS-P0-002 | OPEN | Backup/PITR not production-deployed |
| ACC-OPS-P0-003 | OPEN | **Narrowed:** Gemini/G10/PII/AI canary + remaining mocks — **not** freee/CloudSign |

## P1 / P2 Operations Findings

| ID | Status | Title |
|---|---|---|
| ACC-OPS-P1-001 | OPEN | No metrics/APM export |
| ACC-OPS-P1-002 | SUPERSEDED | CloudSign → ACC-REQ-P0-002 |
| ACC-OPS-P1-003 | SUPERSEDED | freee → ACC-REQ-P0-001 |
| ACC-OPS-P1-004 | SUPERSEDED | Email → REV-P1-005 |
| ACC-OPS-P1-005 | SUPERSEDED | AI/G10/canary → ACC-OPS-P0-003 (expanded) |
| ACC-OPS-P1-006 | OPEN | In-memory sessions — no horizontal scale |
| ACC-OPS-P2-003 | OPEN | Backup unit false-green (464 shell checks; trap_add) |

PITR: sandbox files archived (`pitr-evidence/`) — archive integrity **VERIFIED**; `mysql:8.0.36` digest **BLOCKED**; prod topology restore **BLOCKED**.
