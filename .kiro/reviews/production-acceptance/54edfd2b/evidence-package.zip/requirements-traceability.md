# Requirements Traceability — Production Acceptance

**Frozen commit:** `54edfd2b08f5fd61095b3a94c33bd5b981935c28`  
**Recorded:** 2026-08-24 JST  
**Agent:** A (Requirements & Business Traceability)  
**Conclusion:** **FAIL** (external sandbox + human UAT + stale tasks)

## Scope Reviewed

| Area | Coverage |
|---|---|
| Spec directories | 67 × (`requirements.md`, `design.md`, `tasks.md`) |
| README features | 13 major blocks |
| Test inventory | 465 `*Test.java` |
| Roles | 管理者 / 営業 / HR / マネージャー / 要員 |

## P0/P1 Critical Requirement Inventory (excerpt)

| ID | Requirement | Spec | Implementation | Automated Test | Evidence class | Status |
|---|---|---|---|---|---|---|
| P0-02 | 5-role menu + action permissions | user-account-management | MenuPermissionFilter | ActionPermissionMatrixTest | H2 CI | Present |
| P0-06 | 成約→契約 same TX | proposal-to-contract | ContractServiceImpl | ContractServiceImplTest | H2 CI | Present |
| P0-10 | Monthly closing lock | monthly-closing-checklist | MonthlyClosingServiceImpl | MonthlyClosingServiceImplTest | H2 CI | Present |
| P0-17 | freee payroll HFP-01 | payroll-management | FreeeIntegrationService | FreeeHrContractTest (mock) | External sandbox Demo | **BLOCKED** ACC-REQ-P0-001 |
| P0-18 | CloudSign HFP-02 | contract-document-esign | CloudSignClientImpl | CloudSignClientContractTest | External sandbox Demo | **BLOCKED** ACC-REQ-P0-002 |
| P0-19 | Backup HFP-03 | database-backup-recovery | ops/backup | Docker PITR | Sandbox archive VERIFIED; prod topology **BLOCKED** | ACC-OPS-P0-002 |
| P1-12 | Dispatch G2 | dispatch-outsourcing-compliance-ledger | G2 services | G2GatePhaseAE2ETest | Human UAT | **BLOCKED** ACC-REQ-P1-001 |

## Evidence classes (do not collapse)

| Class | Definition | Status at Run 2 |
|---|---|---|
| **Browser automated evidence** | `-Pbrowser-tests` CDP suite + `target/browser-m-evidence/` | **EXECUTED** — 3 tests, 0 skipped (Run 2 log) |
| **External sandbox Demo** | freee / CloudSign / Gemini-G10 / SMTP credentials against provider sandbox | **BLOCKED** — ACC-REQ-P0-001, ACC-REQ-P0-002, ACC-OPS-P0-003 |
| **Human UAT** | Owner/legal/business sign-off (G2 Phase B, closing-scope policy, prod drill) | **BLOCKED** — ACC-REQ-P1-001, ACC-ARCH-P1-001 |

GO criterion (100% P0/P1 evidence): **NOT MET**. Completeness % (~87% / ~75%) is **not independently recalculable**.

## Incomplete tasks.md (13 specs, **68** open checkboxes)

Tracked as **ACC-REQ-P1-002** (ACC-REQ-P0-003 SUPERSEDED). Count: `rg '^\s*- \[ \]' .kiro/specs --glob tasks.md` → **68**.

| Spec | Open | Assessment |
|---|---:|---|
| contract-document-esign | 11 | HFP-02 production blocker |
| skillsheet-ingestion | 17 | Likely stale vs implemented code |
| work-record-billing | 7 | Stale — billing shipped |
| proposal-contract-workflow | 7 | Stale — workflow shipped |
| multi-company-tenant-isolation | 6 | Not started |
| sales-activity | 5 | Not started |
| rule-based-matching | 5 | Not started |
| payroll-management | 1 | HFP-01-011 sandbox only |
| dispatch-outsourcing-compliance-ledger | 1 | G2 Phase B human UAT |
| Others | 8 | Partial / ops |

## Key Gaps

1. No dedicated `DataScopeIntegrationTest` as spec promises.
2. `RoleNavigationVisibilityTest` is static HTML only.
3. README Feature 7 omits 要員.
4. Spec index vs tasks contradiction (ui-scale).

## Gate execution vs evidence class

| Item | Run 1 | Run 2 |
|---|---|---|
| `verify-like-ci.ps1` | BLOCKED | **PASS** |
| Browser automated evidence | BLOCKED | **EXECUTED** |
| External sandbox Demo | BLOCKED | **BLOCKED** |
| Human UAT | BLOCKED | **BLOCKED** |

## Conclusion

**FAIL** — HFP-01/02 sandbox and G2 human UAT open; stale task ledger (ACC-REQ-P1-002); browser automation is **not** a substitute for sandbox Demo or UAT.
