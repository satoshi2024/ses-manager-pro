# Production Acceptance Baseline

| Field | Value |
|---|---|
| **Frozen commit (full)** | `54edfd2b08f5fd61095b3a94c33bd5b981935c28` |
| **Short SHA** | `54edfd2b` |
| **Commit message** | Merge pull request #83 from satoshi2024/fix/light-theme-content-contrast |
| **Commit time (JST)** | 2026-08-24 10:50:03 +0900 |
| **Baseline recorded (JST)** | 2026-08-24 12:15:00 +0900 |
| **Acceptance lead** | Production Acceptance Agent (read-only) |

## Working Tree

**Rerun (2026-08-24 ~12:48 JST):** Not clean — commit unchanged at `54edfd2b`.

```
 M .kiro/specs/*/evidence/browser/*.png (and related json/txt) — 28 files
?? .kiro/reviews/  (acceptance evidence package — expected)
```

**Impact:** `src/`, `pom.xml`, tests, migrations **unchanged**. Modified files are spec browser evidence artifacts only — **does not invalidate commit freeze** but independent reviewer should note timestamp drift on evidence PNGs.

**Initial pass (12:15 JST):** Working tree was clean.

**Baseline suitability:** **SUITABLE with note** — single commit frozen; non-src dirt documented.

## Environment

| Tool | Version / Status |
|---|---|
| OS | Windows 11 (10.0.26200) |
| Java | OpenJDK Temurin **17.0.20+8** (CI uses JDK **21**) |
| Maven | Apache Maven **3.9.6** (bundled) |
| Node.js | **v24.19.0** (CI uses Node **20**) |
| Docker | **29.7.2** — available (Run 2 verified `docker info` exit 0) |
| Chrome | **151.0.7922.172** at `C:\Program Files\Google\Chrome\Application\chrome.exe` |
| Git Bash | Available at `C:\Program Files\Git\bin\bash.exe` |
| Locale (local) | zh_CN / GBK (CI pins Asia/Tokyo, ja_JP, UTF-8) |

## Available Capabilities

- Fast test suite (H2/unit/MVC)
- MySQL Testcontainers suite (3 shards, Docker)
- Performance regression profile
- Browser demo profile (real Chrome CDP)
- Backup unit + PITR integration (Bash + Docker)
- Node.js syntax checks (JsSyntaxCheckTest)
- Static migration integrity (MigrationScriptIntegrityTest)

## Missing / Blocked Capabilities

| Capability | Status | Impact |
|---|---|---|
| Production MySQL / prod credentials | **BLOCKED** — not authorized | No production canary evidence |
| freee sandbox OAuth + payroll API | **BLOCKED** — credentials required | HFP-01 AC15 cannot PASS |
| CloudSign sandbox closed loop | **BLOCKED** — credentials required | HFP-02 cannot PASS |
| Manual UAT / business sign-off | **BLOCKED** — no signed artifacts | Cannot issue unconditional GO |
| PIT / SpotBugs / Dependency-Check / Gitleaks | **Not configured** | Quality gate GAP |
| JDK parity with CI | **GAP** — local JDK 17 vs CI JDK 21 | Minor; bytecode target is 17 |

~~MySQL Testcontainers / backup integration locally~~ — **Run 2 (12:48 JST): RESOLVED** via full `verify-like-ci.ps1` PASS.

## Repository Inventory (at commit)

| Item | Count / Latest |
|---|---|
| Flyway migration scripts (`db/migration/V*.sql`) | **112** files; highest version **V108_3** |
| Test classes (`*Test.java`) | **465** |
| `@Tag("mysql")` classes | **39** (13+13+13 shards) |
| `@Tag("performance")` classes | **1** |
| `@Tag("browser")` classes | **3** |
| Spec directories with `requirements.md` | **67** |

## Flyway Migration Versions (summary)

Latest incremental: `V108_3__digital_invoice_send_unique.sql`

Notable gaps (by design): V19, V23, V41, V47, V59, V72, V82, V86–V90, V92–V97, V99–V100

Sub-versions present: V66_1, V74_1, V74_2, V102_1–102_4, V103_1, V104_1–104_4, V105_1–105_3, V106_1–106_2, V107_1–107_3, V108_1–108_3

## CI Contract (`.github/workflows/ci.yml`)

| Job | Command | Skip policy |
|---|---|---|
| fast-test | `mvn -B clean test` | Zero skipped |
| mysql-test ×3 | `mvn -B clean test -Pmysql-tests -Dtest=<shard>` | Zero skipped |
| performance-test | `mvn -B clean test -Pperformance-tests` | Zero skipped |
| browser-test | `mvn -B clean test -Pbrowser-tests` | Zero skipped |
| backup-integration | `ops/backup/tests/run-unit-tests.sh` + `run-integration.sh` | Docker required |

Local equivalent: `scripts/verify-like-ci.ps1` (includes browser + backup gates).

## Baseline Blockers (pre-execution)

None structural. Automated gate execution **in progress** at baseline+15m.

## Evidence Directory

`C:\work\ses-manager-pro\.kiro\reviews\production-acceptance\54edfd2b\`
