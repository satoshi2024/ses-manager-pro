# Architecture & Business Integrity Review

**Frozen commit:** `54edfd2b08f5fd61095b3a94c33bd5b981935c28`  
**Agent:** B (Architecture)  
**Severity rubric:** `severity-rubric.md`  
**Automated gates:** Run 2 **PASS**  
**Conclusion:** **FAIL** (ACC-ARCH-P1-001 OPEN)

## Findings Summary

| ID | Sev | Status | Title |
|---|---|---|---|
| ACC-ARCH-P1-001 | P1 | OPEN | Monthly closing summary leaks company-wide data to scoped managers |
| ACC-ARCH-P1-002 | P1 | WITHDRAWN | ~~Proposal→contract race~~ → REV-P2-001 |
| ACC-ARCH-P2-001 | P2 | OPEN | Sales performance exposes all reps' commission to every 営業 |
| ACC-ARCH-P2-002 | P2 | WITHDRAWN | ~~Missing rollbackFor~~ — no checked-exception path on WR/BP |
| ACC-ARCH-P2-003 | P2 | OPEN | HR has closing menu but confirm denied at service layer |
| ACC-ARCH-P2-004 | P2 | OPEN | Unbounded outstanding-balance queries |
| ACC-ARCH-P2-005 | P2 | OPEN | deletePayment skips org write-scope assert |
| ACC-ARCH-P3-001 | P2 | OPEN | Dashboard KPI full-table aggregation (availability at scale) |
| ACC-ARCH-P3-002 | P3 | OPEN | Procurement error raw finding text (low disclosure) |
| ACC-ARCH-P3-003 | P2 | OPEN | DataScope computeContractIds memory (OOM/latency at scale) |

ACC-ARCH-P3-001 / P3-003: ID prefix historical; **Severity column = P2** (load availability, not count-driven).  
ACC-ARCH-P2-002: `WorkRecordServiceImpl` / `BpPaymentServiceImpl` declare no checked `throws`; Spring default rollback covers RuntimeException.

**Run 1 note (superseded):** MySQL gate execution assumed BLOCKED; Run 2 verified.
