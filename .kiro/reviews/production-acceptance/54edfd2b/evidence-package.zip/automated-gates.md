# Automated Gates — Production Acceptance

**Frozen commit:** `54edfd2b08f5fd61095b3a94c33bd5b981935c28`  
**Acceptance host:** Windows 11, JDK 17.0.20, Maven 3.9.6, Node 24.19.0, Docker 29.7.2, Chrome 151.0.7922.172

---

## Run 1 (2026-08-24 12:12 JST) — BLOCKED

| Gate | Result | Reason |
|---|---|---|
| verify-like-ci (full) | **BLOCKED** | Docker daemon unreachable at preflight |

Log: `verify-like-ci.log` — **superseded by Run 2**.

---

## Run 2 (2026-08-24 12:48–13:34 JST) — **ALL PASS**

**Log:** `verify-like-ci-rerun-full.log` · exit **0** · ~46 min

| Gate | Tests | Skipped | Result |
|---|---:|---:|---|
| Fast | 2647 | 0 | PASS |
| MySQL | 61 | 0 | PASS |
| Performance | 1 | 0 | PASS |
| Browser | 3 | 0 | PASS |
| Backup unit | **464** shell assertions | 0 | PASS* |
| Backup PITR | integration | 0 | PASS |
| Ledger | ACC-GATE-P0-001 | — | CLOSED (Run 2 superseded Run 1 Docker BLOCKED) |

\*See **ACC-OPS-P2-003** — false-green concern (`common::trap_add` without `common.sh`).

### Zero-skip verification

Use **four Maven aggregate** `Tests run:` / `Skipped: 0` lines in Run 2 log only.  
Do **not** use `target/surefire-reports/*.xml` after full verify-like-ci (may be Browser-only).

### Backup unit breakdown

| Script | tests |
|---|---:|
| binlog-checkpoint-test.sh | 61 |
| cutover-test.sh | 31 |
| drill-test.sh | 19 |
| full-backup-test.sh | 36 |
| health-test.sh | 29 |
| preflight-test.sh | 59 |
| quiesce-lock-test.sh | 45 |
| restore-flow-test.sh | 31 |
| restore-plan-test.sh | 44 |
| restore-validation-test.sh | 32 |
| retention-test.sh | 55 |
| target-guard-test.sh | 22 |
| **Total** | **464** |

### PITR evidence

- **Source (Run 2):** `ops/backup/tests/.integration-work/evidence/` — 12 files exist on disk
- **Archive:** `.kiro/reviews/production-acceptance/54edfd2b/pitr-evidence/` + `manifest-sha256.txt`
- **MySQL 8.0.36 digest:** **BLOCKED** — see `pitr-evidence-freeze.md`

---

## Conclusion

**Automated hard gates: PASS** (Run 2). Production GO still **NO** per `final-report.md`.
