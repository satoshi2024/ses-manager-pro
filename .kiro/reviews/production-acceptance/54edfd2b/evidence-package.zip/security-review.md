# Security, Privacy & AI Review

**Frozen commit:** `54edfd2b08f5fd61095b3a94c33bd5b981935c28`  
**Agent:** D (Security) — **superseded by independent review**  
**Conclusion:** **FAIL** (revised 2026-08-24)

> Independent review (`independent-review.md`) **reopened P0**. Prior “no P0” claim is **WITHDRAWN**.

## Layered Controls (partially effective)

| Layer | Mechanism | Gap |
|---|---|---|
| Page | SecurityConfig static matchers | **REV-P1-001** — admin surfaces in `hasAnyRole(管理者,HR,マネージャー)` |
| Menu | MenuPermissionFilter | Empty menu → pass-through (`:121`) enables identity API |
| Action | AuthorizationService baseline + deny | V66_1 seeds `identity-provider.*` for HR/manager |
| Data | DataScopeServiceImpl | — |
| File | FileScopeValidationService | Fail-closed — still OK |
| AI | PII canary | **REV-P1-004** — skipped for `INGEST_*` |

## Critical Findings (post independent review)

| ID | Sev | Title |
|---|---|---|
| **REV-P0-001** | **P0** | HR/マネージャー OIDC bind → admin takeover |
| REV-P1-001 | P1 | Admin hard-boundary matcher wrongly widened |
| REV-P1-002 | P1 | Webhook URL blind SSRF |
| REV-P1-003 | P1 | Browser API key sent to server |
| REV-P1-004 | P1 | AI ingestion PII bypass |
| REV-P1-005 | P1 | Mail DRY_RUN logs full body |
| REV-P1-006 | P1 | Accidental `dev` profile deploy |
| ACC-SEC-P1-001 | P1 | No dependency CVE scanning (includes former ACC-TEST-P1-003) |
| ACC-SEC-P1-003 | P1 | Gemini `ai.api-url` SSRF class |

## P0 Security

**OPEN: REV-P0-001** — see `SecurityConfig.java:142–169`, `V66_1:24`, `ExternalIdentityApiController`, `ExternalIdentityProvisioningServiceImpl`, `MenuPermissionFilter:121`.

## Conclusion

**FAIL** — Do not ship. Fix Batch 1 (identity + admin hard boundary) is mandatory before re-acceptance.
